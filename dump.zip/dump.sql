-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                11.1.2-MariaDB-1:11.1.2+maria~ubu2204 - mariadb.org binary distribution
-- Server OS:                    debian-linux-gnu
-- HeidiSQL Versie:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Databasestructuur van newsletters wordt geschreven
CREATE DATABASE IF NOT EXISTS `newsletters` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `newsletters`;

-- Structuur van  tabel newsletters.sdgs wordt geschreven
CREATE TABLE IF NOT EXISTS `sdgs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `color` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel newsletters.sdgs: ~17 rows (ongeveer)
DELETE FROM `sdgs`;
INSERT INTO `sdgs` (`id`, `title`, `img`, `text`, `color`) VALUES
	(1, 'Geen armoede', 'sdg1.svg', 'Einde aan de armoede gaat over het verminderen van alle vormen van armoede. De SDG-agenda vraagt speciale aandacht voor sociale bescherming, gelijke economische rechten en weerbaarheid van arme en kwetsbare groepen. Omdat armoede in Nederland er anders uit ziet dan armoede in de armste landen van de wereld is dit voor Nederland aangepast. Nederland richt zich op het voorkomen en tegengaan van armoede en problematische schulden, met speciale aandacht voor kinderen die in armoede leven.\r\n', '#FF0000'),
	(2, 'Geen honger', 'sdg2.svg', 'Einde aan honger, zorgen voor voedselzekerheid en duurzame landbouw', '#EDAA10'),
	(3, 'Goede gezondheid en welzijn', 'sdg3.svg', 'Goede gezondheid en welzijn gaat over dat iedereen de kans heeft in zo goed mogelijke gezondheid te leven, door behandeling van ziektes en psychische problemen en voorkomen dat mensen te vroeg sterven. Dit doel gaat ook over het tegengaan van verslaving ( alcohol, drugs, roken) en ook over het voorkomen van verkeersdoden.', '#00A000'),
	(4, 'Kwaliteitsonderwijs', 'sdg4.svg', 'Inclusief, gelijkwaardig en kwalitatief onderwijs voor iedereen', '#DA0822'),
	(5, 'Gendergelijkheid', 'sdg5.svg', 'Mannen en vrouwen moeten gelijk behandeld worden en een gelijkwaardige plek in de samenleving hebben. Hiervoor moet een eind komen aan achterstand van vooral vrouwen en meisjes op allerlei gebieden, waaronder dwang en geweld, werk en zorg, maar ook invloed in het openbare leven.', '#FF4000'),
	(6, 'Schoon water en sanitair', 'sdg6.svg', 'De toegang tot drinkwater en sanitair en duurzaam beheer van water vormen de kern van SDG 6. Vrijwel iedereen in Nederland heeft toegang tot schoon drinkwater en goed sanitair. Drinkwater moet betaalbaar blijven voor ons allemaal. De vraag naar drinkwater is tijdens de afgelopen droge en hete zomers gestegen. Ook de groeiende bevolking en de behoefte aan meer woningen, en daarmee meer aansluitingen, zorgen voor meer vraag. Omdat er weinig mogelijkheden zijn om meer water te winnen, concurreren drinkwaterbedrijven steeds vaker met de belangen van natuur, landbouw en klimaatactie. Als er vaker droge zomers vaker voorkomen, kan de leveringszekerheid van drinkwater op termijn onder druk komen.', '#00AED9'),
	(7, 'Betaalbare en schone energie', 'sdg7.svg', 'Energiezekerheid, verduurzaming en energie-efficiëntie zijn erg belangrijk. Steeds minder mensen hebben de mogelijkheid om voldoende energie te gebruiken omdat het heel duur is geworden. In koude winters gebruiken veel mensen daarom extra dikke kleding en dekens om lekker warm te blijven en de kachel een beetje kouder te zetten.', '#FDBE00'),
	(8, 'Waardig werk en economische groei', 'sdg8.svg', 'Economische groei, met aandacht voor innovatie, ondernemerschap en milieu is erg belangrijk voor een duurzame wereld. Economische activiteiten kunnen op lange termijn schadelijk zijn voor de brede welvaart, de leefomgeving en het welbevinden van de mensen en dieren. Voor de productie van goederen en diensten is input nodig van kapitaal, arbeid en grondstoffen. Worden deze duurzaam en productief ingezet? En hoe worden de winsten en inkomens verdeeld worden over burgers en bedrijven?', '#9F0830'),
	(9, 'Industrie, innovatie en infrastructuur', 'sdg9.svg', 'Infrastructuur en mobiliteit, industrie en duurzame bedrijvigheid, en kennis en innovatie zijn belangrijk in een duurzame wereld. Een toegankelijke infrastructuur en mobiliteit voor iedereen. Mobiliteit en infrastructuur helpen mensen om van plek a naar plek b te komen, bijvoorbeeld naar het werk, contacten te onderhouden en vrije tijd in te vullen met sport, muziek of theater. Als mensen lang in de file staan dan is dat nadelig voor het milieu en wanneer mensen te hard rijden dan gaat het niet goed met de verkeersveiligheid en het milieu.', '#FF6919'),
	(10, 'Ongelijkheidsvermindering', 'sdg10.svg', 'Sociale samenhang is onmisbaar voor het goed functioneren van een samenleving. De sociale infrastructuur – familie, buren, vrienden, verenigingen en hulp en ondersteuning – vormt hiervan de basis. Mensen moeten mee kunnen doen, zodat ze zich deel van een groep kunnen voelen. Dat geldt ook voor mensen uit andere landen die hier komen werken.', '#FF006E'),
	(11, 'Duurzame steden en gemeenschappen', 'sdg11.svg', 'Er zijn weinig betaalbare woningen beschikbaar, hoe houden we de lokale leefomgeving veilig, betaalbaar, toegankelijk en duurzaam? Hoeveel ruimte is er per persoon beschikbaar en hoe gaat het met de afvalverwerking en overheidsuitgaven voor het milieu. Een schone en veilige leefomgeving in het dorp, de wijk of de stad is daarbij erg belangrijk.', '#F9B000'),
	(12, 'Verantwoorde consumptie en productie', 'sdg12.svg', 'Bedrijven, overheid en consumenten worden aangespoord om bewuste keuzes te maken om de druk op het milieu te verlagen en minder afhankelijk te zijn van grondstoffen. Zo beperken we de negatieve gevolgen van ons consumptie voor volgende generaties.', '#F08700'),
	(13, 'Klimaatactie', 'sdg13.svg', 'Door doelen te stellen voor weerbaarheid en klimaatadaptatie, nationaal klimaatbeleid, en middelen om bewustwording en draagvlak te creëren voor de klimaatmaatregelen. Met het Deltaprogramma, dat Nederland moet beschermen tegen overstromingen en de gevolgen van extreem weer, kunnen we belangrijke stappen maken. Ook de vermindering van uitstoot van broeikasgassen, waarbij energiebesparing en hernieuwbare energie spelen een belangrijke rol.', '#379223'),
	(14, 'Leven in het water', 'sdg14.svg', 'Zeewater bedekt ongeveer driekwart van de planeet en vormt het grootste ecosysteem ter wereld. De toenemende negatieve effecten van klimaatverandering, overbevissing en vervuiling vormen een bedreiging voor de waarde van het ecosysteem zelf en voor het gebruik dat ervan gemaakt wordt. Aandacht voor de waterkwaliteit en de duurzaamheid van de visserij in de Noordzee zijn voor ons erg belangrijk.', '#0D81DF'),
	(15, 'Leven op het land', 'sdg15.svg', 'Bescherming en herstel van ecosystemen en biodiversiteit versterken de weerbaarheid tegen toenemende bevolkingsdruk, intensivering van landgebruik en klimaatverandering. Gezonde ecosystemen zijn erg belangrijk zoals de beschikbaarheid van schoon water en schone lucht, de aanwezigheid van insecten voor bestuiving en de mogelijkheden voor ontspanning, recreatie en educatie.', '#56C739'),
	(16, 'Vrede, justitie en sterke instellingen', 'sdg16.svg', 'Voor veiligheid en vrede moeten alle vormen van geweld en de sterfte die daarvan het gevolg is verminderd worden. Speciale aandacht gaat uit naar geweld tegen kinderen en naar georganiseerde misdaad. In een veilige samenleving heeft iedereen toegang tot het rechtssysteem, en wordt corruptie tegengegaan. Het ervaren van onveiligheid, met gevoelens van kwetsbaarheid en onzekerheid kunnen een grote impact hebben op het persoonlijke leven.', '#0E559C'),
	(17, 'Partnerschappen voor de doelen', 'sdg17.svg', 'Dit vraagt om samenhangend beleid, een meewerkende omgeving en de bereidheid tot aangaan van nieuwe partnerschappen. Met wie werk je samen en waarom? Het gaat er bij dit doel om welk effect ontwikkelingen in Nederland op andere landen hebben.', '#362397');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
